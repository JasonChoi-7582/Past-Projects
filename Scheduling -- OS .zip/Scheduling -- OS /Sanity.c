#include "types.h"
#include "user.h"
#include "stat.h"

int main(void){
    int total_wait = 0;
    int total_run = 0;
    int total_stat = 0;
    int i, pid,j;
    int total = 0;
    for(i = 0; i < 20; i++){
        pid = fork();
        if(pid == -1){
            printf(1, "Fork Failed! \n");
            exit();
        }
        //creating randomg processes to take 30 ticks
        if(pid ==0){
            for(j = 0; j < 10000; j++){
                total = j - j + total;
            }
            exit();
        }

    }
    int wt = 0;
    int rt = 0;
    int iot = 0;
    int stat = 0;
    int count = 0;
    while(wait_stat(&wt, &rt, &iot, &stat) != -1){
        total_wait += wt;
        total_run += rt;
        total_stat += wt + rt + iot;
        printf(1, "Child %d has waited: %d, run: %d, tat = %d\n", count, wt, rt, wt+rt+iot);
        count ++;
    }
    printf(1, "Parent finished\n");
    printf(1, "Wait time average: %d\n", total_wait/20);
    printf(1, "Rumtime average: %d\n", total_run/20);
    printf(1, "Average TAT: %d", total_stat/20);
    exit();
}